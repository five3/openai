
function reloadRequestInfo() {
    console.log("reload status");
    let data = wps.PluginStorage.getItem("request_info")
    if (!data) return;

    console.log("got status info");
    document.getElementById("status").innerText = data.status;
    if (data.endTime) {
        document.getElementById("timeCost").innerText = (data.endTime - data.startTime) / 1000;
    } else {
        document.getElementById("timeCost").innerText = (new Date().getTime() - data.startTime) / 1000;
    }
    document.getElementById("question").innerText = data.question;
    document.getElementById("answer").value = data.answer;
}


window.onload = function () {
    console.log("help page is loaded");
    reloadRequestInfo();
}